package com.local.alojamento.repository;


import com.local.alojamento.models.Imovel;
import com.local.alojamento.models.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;
import org.springframework.util.MultiValueMap;

@Repository
@EnableJpaRepositories
public interface ImovelRepository extends JpaRepository<Imovel, Long> {
    Imovel findById(long id);

    default Imovel delete(Long imovelId) {
        //Usuario = null;
        return null;
    }
}