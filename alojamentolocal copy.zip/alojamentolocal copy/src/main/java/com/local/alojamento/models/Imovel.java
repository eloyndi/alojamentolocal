package com.local.alojamento.models;


import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table (name = "imovel")
public class Imovel implements Serializable {
    private static final long serialVertionUID= 1l;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    private String Nome;
    private int area;
    private int telefone;
    private String email;


    @OneToMany(mappedBy = "imovel",fetch = FetchType.LAZY,cascade = CascadeType.ALL)
    private List<Usuario> usuarios;
    //private  List<Quarto> quarto;

    @OneToMany(mappedBy = "imovel",fetch = FetchType.LAZY,cascade = CascadeType.ALL)
    private List<Quarto> Quartos;

    public static long getSerialVertionUID() {
        return serialVertionUID;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public int getArea() {
        return area;
    }

    public void setArea(int area) {
        this.area = area;
    }

    public int getTelefone() {
        return telefone;
    }

    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDetalhe() {
        return detalhe;
    }

    public void setDetalhe(String detalhe) {
        this.detalhe = detalhe;
    }

    private String detalhe;

}
