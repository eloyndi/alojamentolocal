package com.local.alojamento.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javafx.scene.chart.XYChart;

import javax.persistence.*;
import javax.persistence.criteria.Fetch;
import javax.xml.crypto.Data;
import java.io.Serializable;
import java.util.List;
import com.local.alojamento.models.Quarto;
import com.sun.istack.internal.NotNull;

@Entity
@Table(name="usuario")
public class Usuario implements Serializable {
    private static final long serialVertionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @NotNull
    private long id;
    @NotNull
    private String nome;
    @NotNull
    private String apelido;
    @NotNull
    private boolean sexo;
    @NotNull
    private String email;
    private int numero;
    @NotNull
    private int data_nascimento;
    private int nif;

    public boolean isSexo() {
        return sexo;
    }

    public void setSexo(boolean sexo) {
        this.sexo = sexo;
    }

    @ManyToOne(fetch=FetchType.LAZY )
    @JoinColumn(name = "quartoId")

    private Quarto quarto;
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getApelido() {
        return apelido;
    }

    public void setApelido(String apelido) {
        this.apelido = apelido;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public int getData_nascimento() {
        return data_nascimento;
    }

    public void setData_nascimento(int data_nascimento) {
        this.data_nascimento = data_nascimento;
    }

    public int getNif() {
        return nif;
    }

    public void setNif(int nif) {
        this.nif = nif;
    }

    public static long getSerialVertionUID() {
        return serialVertionUID;
    }

    public Quarto getQuarto() {
        return quarto;
    }

    public void setQuarto(Quarto quarto) {
        this.quarto = quarto;
    }
}
