package com.local.alojamento.resources;

import com.local.alojamento.models.Quarto;
import com.local.alojamento.models.Usuario;
import com.local.alojamento.repository.QuartoRepository;
import com.local.alojamento.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value="/api")
public class QuartoResource {

    @Autowired
    QuartoRepository quartoRepository;

    public Quarto salvar(Quarto quarto){
        return quartoRepository.save(quarto);

    }
    @DeleteMapping(value ="/apagar")
    public boolean excluir(Long quartoId){
        Quarto quartoFind = quartoRepository.getOne(quartoId);
        if (quartoFind != null){
            quartoRepository.delete(quartoFind);
            return true;
        }
        else{
            return false;
        }
    }

    public List<Quarto> buscarTodos(){
        return quartoRepository.findAll();
    }

    @GetMapping("/quartos")
    public List<Quarto> listaQuartos(){

        return quartoRepository.findAll();
    }
}
