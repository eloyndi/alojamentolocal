package com.local.alojamento.models;


import org.hibernate.engine.jdbc.SerializableBlobProxy;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

import com.local.alojamento.models.Usuario;

@Entity
@Table(name="quarto")
public class Quarto implements Serializable {

    private static final long serialVertionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    private int numero;
    private boolean disponivel=true;
    private float valor;

    @OneToMany(mappedBy = "quarto",fetch = FetchType.LAZY,cascade = CascadeType.ALL)
    private List<Usuario>  usuario;
    @OneToMany(mappedBy = "quarto",fetch = FetchType.LAZY,cascade = CascadeType.ALL)
    private List<Imovel> imovels;

    public static long getSerialVertionUID() {
        return serialVertionUID;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public boolean isDisponivel() {
        return disponivel;
    }

    public void setDisponivel(boolean disponivel) {
        this.disponivel = disponivel;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public List<Usuario> getUsuario() {
        return usuario;
    }

    public void setUsuario(List<Usuario> usuario) {
        this.usuario = usuario;
    }
}
