package com.local.alojamento.resources;

import com.local.alojamento.models.Usuario;
import com.local.alojamento.repository.UsuarioRepository;
import jdk.internal.org.objectweb.asm.tree.analysis.Value;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping(path="/api")
public class UsuarioResource {
    @Autowired
    UsuarioRepository usuarioRepository;

    @PostMapping(path = "/salvar")
    public ResponseEntity<?> salvar(@Validated @RequestBody Usuario usuario){
        return new ResponseEntity(usuarioRepository.save(usuario), HttpStatus.CREATED);
    }

    @PutMapping(path = "/alterar")
    public ResponseEntity<?> alterar(@Validated @RequestBody Usuario usuario){
        return new ResponseEntity<>(usuarioRepository.save(usuario), HttpStatus.OK);
    }

    @DeleteMapping(value = "/{usuarioId}")
    public ResponseEntity<?> excluir(@PathVariable Long usuarioId){
        return new ResponseEntity(usuarioRepository.delete(usuarioId),HttpStatus.OK);
    }

    @GetMapping(path = "/usuarios")
    public ResponseEntity<?> listaUsuarios(){

        return ResponseEntity.status(HttpStatus.OK).body(usuarioRepository.findAll());
       // return new ResponseEntity(usuarioRepository.findAll(),HttpStatus.OK);
       // return usuarioRepository.findAll();
    }

}

