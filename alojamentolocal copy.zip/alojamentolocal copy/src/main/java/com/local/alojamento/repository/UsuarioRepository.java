package com.local.alojamento.repository;

import com.local.alojamento.models.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
//import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

Usuario findById(long id);

    default Usuario delete(Long usuarioId) {
        //Usuario = null;
       return null;
    }
}
